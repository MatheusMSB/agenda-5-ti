/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tabuada;

/**
 *
 * @author mathe
 */
public class Tabuada {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //loop para cada numero de 6 a 10
        for (int numero = 6; numero <=10; numero ++) {
            System.out.println("Tabuada do numero " + numero + ":");
            //loop para cada multiplicador de 1 a 10
            for ( int multiplicador = 1; multiplicador<=10; multiplicador++){
                int resultado = numero * multiplicador;
                System.out.println(numero + "x" + multiplicador + "=" + resultado);
                }
            System.out.println(); // adicona uma linha de espaço entre as tabuadas
        }
    }
    
}
