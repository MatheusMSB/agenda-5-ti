package javaapplication8;

import java.util.Scanner;

public class PesquisaAtendimentoCliente {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int excelenteCount = 0;
        int ruimCount = 0;
        
        for (int i = 1; i <= 50; i++) { // 50 entrevistados
            System.out.println("Entrevistado #" + i);
            System.out.print("Nome: ");
            String nome = scanner.nextLine();
            
            System.out.print("Idade: ");
            int idade = Integer.parseInt(scanner.nextLine());
            
            System.out.println("Opinião sobre o atendimento:");
            System.out.println("1 - EXCELENTE");
            System.out.println("2 - BOM");
            System.out.println("3 - RUIM");
            System.out.print("Escolha uma opção (1/2/3): ");
            int opcao = Integer.parseInt(scanner.nextLine());
            
            // Verificar opinião
            switch (opcao) {
                case 1:
                    excelenteCount++;
                    break;
                case 3:
                    ruimCount++;
                    break;
                default:
                    break;
            }
        }
        
        // Exibir resultados
        System.out.println("\nResultados da pesquisa:");
        System.out.println("Quantidade de respostas EXCELENTES: " + excelenteCount);
        System.out.println("Quantidade de respostas RUINS: " + ruimCount);
        
        scanner.close();
    }
}
